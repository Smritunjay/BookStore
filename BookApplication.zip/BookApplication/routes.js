'use strict';

const express = require('express');
const router = express.Router();
const fileCtrl = require('./app/controller.js');
const file = new fileCtrl();

// middleware that is specific to this router
router.use((req, res, next) => {
    console.log('Time: ', Date.now())
    next()
});

/* GET home page. */
router.get('/', (req, res, next) => {
    res.render('home', {
        title: 'Express'
    });
});

router.get('/read', (req, res) => {
    file.getFile(req, res);
});

router.post('/save/file', (req, res) => {
    file.getFile(req, res);
});

router.patch('/update/file/:id', (req, res) => {
    file.getFile(req, res);
});

router.delete('/delete/file/:id', (req, res) => {
    file.getFile(req, res);
});

module.exports = router