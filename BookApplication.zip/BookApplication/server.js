'use strict';

//set up
const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const morgan = require('morgan');
const mongoose = require('mongoose');
const http = require('http');
const cors = require('cors');
const routes = require('./routes.js');
const Port = process.env.PORT || 3035;
const app = express();

//db setup

const dbHost = process.env.DB_HOST || 'localhost';
const dbPort = process.env.DB_PORT || '27017';
const dbName = process.env.DB_NAME || 'Book';

const dbURL = 'mongodb://' + dbHost + ':' + dbPort + '/' + dbName;

mongoose.connect(dbURL);//DB connection

app.use(express.static(__dirname + '/public'));
app.use(bodyParser());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(morgan('dev')); // log message
app.use(methodOverride('X-HTTP-Method-Override'));
app.use(cors());

//default routes
app.use(routes);

http.createServer(app).listen(Port, () => {
    console.log(`server is running on ${Port} successfully`);
});

module.exports = app;