
Simple steps to start server-

1) Create DataBase with  "csvimport"
2) Run MongoDB server
3) Install dependencies
         "npm i"
4) To run server type command
         "node server.js"
   (When server will start automatic csv file read and save into DB)
5) In browser use url-
     "http://localhost:3035"                     