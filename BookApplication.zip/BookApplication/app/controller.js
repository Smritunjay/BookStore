'use strict';

const fileService = require('../app/service');
const fileSrv = new fileService();

class FileCtrl {

    getFile(req, res) {
        fileSrv.getFile().then((data) => {
            res.json(data);
        }).catch((err) => {
            res.send(err);
        });
    }

    saveFile(req, res) {
        fileSrv.save(req.body).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.send(err);
        });
    }

    updateFile(req, res) {
        fileSrv.update(req.params.id, req.body).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.send(err);
        });
    }

    deleteFile(req, res) {
        fileSrv.delete(req.params.id).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.send(err);
        });
    }

}

module.exports = FileCtrl;