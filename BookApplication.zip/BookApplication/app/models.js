'use strict';

const mongoose = require('mongoose');

const FileSchema = mongoose.Schema({
    id: {
        type: Number,
        required: true
    },
    level: {
        type: String,
        required: true
    },
    cvss: {
        type: Number,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    vulnerability: {
        type: String,
        required: true
    },
    solution: {
        type: String,
        required: true
    },
    reference: {
        type: String,
        required: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('CSVFILE', FileSchema);