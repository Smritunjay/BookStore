'use strict';

const fileSchema = require('../app/models');

class ReadFile {

    getFile() {
        return new Promise((resolve, reject) => {
            fileSchema.find((err, resp) => {
                if (err) {
                    reject('no data found ', err)
                } else {
                    resolve(resp);
                }
            });
        });
    }

    save(fileData) {
        return new Promise((resolve, reject) => {
            fileSchema.create(fileData, (err, resp) => {
                if (err) {
                    reject('no data found ', err)
                } else {
                    resolve(resp);
                }
            });
        });
    }

    update(id, fileData) {
        return new Promise((resolve, reject) => {
            fileSchema.findOneAndUpdate(id, fileData, {
                $set: true
            }, (err, resp) => {
                if (err) {
                    reject('no data found ', err)
                } else {
                    resolve(resp);
                }
            });
        });
    }

    delete(id) {
        return new Promise((resolve, reject) => {
            fileSchema.delete(id, (err, resp) => {
                if (err) {
                    reject('no data found ', err)
                } else {
                    resolve(resp);
                }
            });
        });
    }

}

module.exports = ReadFile;